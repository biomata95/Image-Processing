arquivo=$1

python source/main.py $arquivo
