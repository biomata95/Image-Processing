#!/usr/bin/python
import sys
import os
import numpy as np
import numpy.random as rnd
import glob
import cv2
import math
import colorsys
import matplotlib.pyplot as plt
import histo


# Funcao principal do programa e leitura do arquivo

def leituraArquivo(arqImagem): # leitura do arquivo
	imagem = cv2.imread(arqImagem) 
	imagem = cv2.cvtColor(imagem,cv2.COLOR_BGR2HSV) # conversao da imagem para HSV
	return imagem

if __name__ == "__main__":
	arquivo=sys.argv[1]; # nome do arquivo -> imagem
	lista=glob.glob("Archive/*.png") # Varreduras dos arquivos .png do diretorio Archive/
	img=leituraArquivo(arquivo)
	histo.histograma(img,lista) # funcao principal que calcula a comparacao do histograma e demais

