#!/usr/bin/python
import sys
import os
import numpy as np
import numpy.random as rnd
import glob
import cv2
import math
import colorsys
import matplotlib.pyplot as plt

# Funcoes que auxiliam na classificacao da imagem

def classificacao(porcentagem): # classificao das comparacoes em 5 categorias. Identico/Parecido/Meio-Parecido/Diferente/Muito-Diferente. Retorna string com classificacao
	classifica=' '
	if(porcentagem<=100 and porcentagem > 75):
		classifica='Parecido'
	if(porcentagem<=75 and porcentagem >=50):
		classifica='Meio-Parecido'
	if(porcentagem<50 and porcentagem >25):
		classifica='Diferente'
	if(porcentagem>=0 and porcentagem<=25):
		classifica='Muito-Diferente'
	return classifica

def porcentagemFinal(elementos): # Operacao da porcentagem, com media e desvio padrao
	soma=0
	for i in range(0,4):
		soma=soma+elementos[i]
	media=soma/4
	variancia=0
	for i in range(0,4):
		variancia=variancia+((elementos[i]-media)*(elementos[i]-media))
	desvio=math.sqrt(variancia)
	porcentagem=(media-1)*100+desvio
	return porcentagem

def resultadoComparacao(histTeste,histComparativa,base): # operacoes principais de Comparacao	
	elementos=[] # vetor com as comparacoes resultantes de cada metodo		
	for i in range(0,4): # loop de metodos
		resultado = cv2.compareHist(histTeste,histComparativa,i) # resultado de cada comparacao em relacao a seu metodo		
		if(i==0 or i==2): # Operacoes de Intersection e Correlation. Sera obtida uma porcentagem entre o histograma de comparacao com o da imagem Teste
			final=(resultado/base[i])
			final=final+1
			elementos.append(final)

		if(i==1): # Qui-Quadrado. O qui-quadrado obtem resultado 0 para Match, e para Mismatch valores que podem tender ao infinito. Logo foi colocado um valor arbitrario para equilibrar o resultado das comparacoes. O valor eh 0.5(50%)
			if(resultado==0):
				final=1
				final=final+1
				elementos.append(final)

			else:
				final=0.5
				final=final+1
				elementos.append(final)

		if(i==3): # Batthacharyya. No batthacharyya o Match eh 0 e o Mismatch eh 1. Logo a operacao realiza para se encontrar a porcentagem no batthacharyya eh o diferenca entre 1 e o resultado, se o valor final for 0:Match, Senao 1:Mismatch
			final=(1-resultado)
			final=final+1
			elementos.append(final)

	porcentagem=porcentagemFinal(elementos) # funcao que calcula a porcentagem final das comparacoes
	classificado=classificacao(porcentagem) # classificacao final em strings
	return classificado
			


