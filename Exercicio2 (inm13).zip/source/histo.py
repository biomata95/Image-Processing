#!/usr/bin/python
import sys
import os
import numpy as np
import numpy.random as rnd
import glob
import cv2
import math
import colorsys
import matplotlib.pyplot as plt
import classifi


# Funcao principal do histograma que acessa as demais funcoes auxiliares


def histograma(imagemTeste,listaFiguras):
	histTeste = cv2.calcHist( [imagemTeste], [0, 1], None, [180, 256], [0, 180, 0, 256] ) # histograma imagem original
	cv2.normalize(histTeste,histTeste,0,255,cv2.NORM_MINMAX) # histograma da imagem original eh normalizado
	classificacoes=[] # vetor com as classificacoes finais
	base=[] # vetor com as comparacoes da imagem Teste com ela mesma
	for p in range(0,4): # insercao das comparacoes da imagem Teste com ela mesma, em relacao a cada metodo
		base.append(cv2.compareHist(histTeste,histTeste,p))
	for i in range(0,14): # Loop de classificacao das imagens.
		comparativa=cv2.imread(listaFiguras[i]) # abertura da imagem da lista de Figuras
		comparativa = cv2.cvtColor(comparativa,cv2.COLOR_BGR2HSV) # imagem convertida de RGB para HSV
		histComparativa = cv2.calcHist( [comparativa], [0, 1], None, [180, 256], [0, 180, 0, 256] ) # histograma da imagem a ser Comparada
		cv2.normalize(histComparativa,histComparativa,0,255,cv2.NORM_MINMAX) # normalizacao do histograma da imagem comparada
		comparacaoFinal=classifi.resultadoComparacao(histTeste,histComparativa,base)	# funcao que compara o histograma das duas figuras.	
		classificacoes.append(comparacaoFinal) # resultado da comparacao inserido em um vetor 
			

	plt.rcParams["figure.figsize"] = [15,7] # tamanho do frame
	fig, axes = plt.subplots(nrows=3,ncols=len(listaFiguras)/2) # Tamanho do Painel.
	imagemTeste = cv2.cvtColor(imagemTeste, cv2.COLOR_HSV2RGB) # conversao da figura Teste de HSV para RGB
	meio=len(listaFiguras)/4 # meio eh a posicao onde a figura Teste estara no frame
	axes[0,meio].imshow(imagemTeste) # impressao da imagem Teste
	axes[0,meio].axis('off') # desabilita os valores nos eixos
	axes[0,meio].set_title('Figura Teste') # seta o titulo da figura
	k=0 # variavel de controle para indicar indices do vetor da lista de Figuras
	for i in range(0,3): # loop que percorre o numero de linhas
		for j in range(0,math.trunc(len(listaFiguras)/2)): # loop que percorre as colunas
			if(i==0): # Desabilita todos os eixos da primeira linha 
				axes[i,j].axis('off')
			else:
				imag=cv2.imread(listaFiguras[k]) # leitura da figura
				axes[i,j].axis('off') # desabilita eixos
				imag = cv2.cvtColor(imag, cv2.COLOR_BGR2RGB)
				axes[i,j].set_title(classificacoes[k]) # imprime classificacao
				axes[i,j].imshow(imag) # ilustra imagem
				k=k+1
	fig.show() # mostra frame
	plt.pause(100000000)

