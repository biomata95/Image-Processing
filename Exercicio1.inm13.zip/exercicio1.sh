arquivo=$1
grauAmostragem=$2	
nivelCinza=$3
tecnica=$4

python source/main.py $arquivo $grauAmostragem $nivelCinza $tecnica


