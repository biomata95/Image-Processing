#!/usr/bin/python
import sys
import numpy as np
import cv2
import math
import colorsys
import leituraVisualiza
import amostragem
import conversaoCinza
import tecnicas
import quantizacao

# Funcao Principal

def main():

	arquivo=sys.argv[1]; # nome do arquivo -> imagem
	grauAmostragem=sys.argv[2]; # grau de amostragem	
	nivelCinza=sys.argv[3]; # grau de cinza
	tecnica=sys.argv[4]; # tecnica de quantizacao
	grauAmostragem=float(grauAmostragem) #conversao da amostragem para float
	percentual=grauAmostragem/100 # resultado da porcentagem em real

	nivelCinza=int(nivelCinza) # deixa tomCinza de String para Int

 	img=leituraVisualiza.leitura(arquivo) #leitura do arquivo

	linhas,colunas,canais=img.shape # linhas,colunas e canais da imagem
	if(percentual>0 and percentual<1): #calcula percentual de amostragem que deve ser entre 0 e 100 com input do programa
		img,linhas,colunas=amostragem.amostragem(img,linhas,colunas,percentual)

	leituraVisualiza.visualizarImagem(img) #visualiza imagem com amostragem
	
	img=conversaoCinza.conversaoCinza(img,linhas,colunas,tecnica) # conversao da imagem para escala cinza 

	if(nivelCinza<8 and nivelCinza>0): #niveis de cinza devem estar entre 0 e 8
		print('operacao de quantizacao em execucao')
		img=quantizacao.quantizacao(img,linhas,colunas,nivelCinza,tecnica) # realiza a quantizacao da imagem apos a conversao para escala cinza

	leituraVisualiza.visualizarImagem(img) # visualiza a Imagem resultante
	

if __name__ == "__main__":
	main()
