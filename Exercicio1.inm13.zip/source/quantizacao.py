#!/usr/bin/python
import sys
import numpy as np
import cv2
import math
import colorsys
import leituraVisualiza
import amostragem
import conversaoCinza
import tecnicas

 # Realiza a quantizacao com a escala de cores desejada pelo usuario

def quantizacao(imag,linhas,colunas,nivelCinza,tecnica):
	tons=256/(256/(2**nivelCinza)) # calcula quantos tons de cinza a imagem tera.
	variacao=(256/(2**nivelCinza)) # calcula a variacao de tons tera. Se eh de: 32,64
	for i in range(0,linhas):
		for j in range(0,colunas):
			pixel=imag[i,j]
			resPixel=tecnicas.calculoTecnica(pixel,tecnica) # calcula o pixel em relacao a tecnica
			modulo=(resPixel%variacao) # obtem o modulo entre o pixel e a variacao de tons
			if(resPixel<variacao): # verifica se o pixel eh menor que a variacao. Se eh automatica a posicao recebe 0.
				imag[i,j]=0
			else:
				resPixel=(resPixel-modulo) # diferenca entre o pixel e o modulo
				resPixel=resPixel+variacao-1 # a soma da diferenca com a variacao, para que o pixel resultante fique dentro das escalas
				imag[i,j]=resPixel
			
	return imag

