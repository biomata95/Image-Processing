#!/usr/bin/python
import sys
import numpy as np
import cv2
import math
import colorsys
import amostragem
import conversaoCinza
import tecnicas
import quantizacao

# Leitura do arquivo(imagem) e Visualizacao da imagem

def leitura(arquivo): # leitura do arquivo de imagem
	img = cv2.imread(arquivo) 
	return img

def visualizarImagem(img): # visualiza imagem
	cv2.imshow('image',img)
	cv2.waitKey(0)
	cv2.destroyAllWindows()

