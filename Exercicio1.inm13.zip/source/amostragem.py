#!/usr/bin/python
import sys
import numpy as np
import cv2
import math
import colorsys
import leituraVisualiza
import conversaoCinza
import tecnicas
import quantizacao


 # Calcula a amostragem da imagem. E retorna a imagem alterada

def amostragem(imag,linhas,colunas,percentual):
	linhas2=linhas*percentual # calcula o numero de linhas da nova resolucao
	linhas2=int(linhas2)
	colunas2=colunas*percentual # calcula o numero de colunas da nova resolucao
	colunas2=int(colunas2)
	imagAlterada=cv2.resize(imag,(colunas2,linhas2)) # redimensiona a nova imagem
	return imagAlterada,linhas2,colunas2

