#!/usr/bin/python
import sys
import numpy as np
import cv2
import math
import colorsys
import leituraVisualiza
import amostragem
import conversaoCinza
import quantizacao

# Tecnicas de quantizacao da imagem

def ordena(pixel):  # Operacao de ordenacao da do vetor de pixels. Bubble sort(poucos elementos).Retorno o pixel ordenado

	for i in range(0,3):
		for j in range(1,3):
			if(pixel[i]>pixel[j]):
				aux=pixel[i]
				pixel[i]=pixel[j]	
				pixel[j]=aux
	return pixel	


def mediana(pixel): # calcula a mediana do vetor pixel. Retorno o elemento do meio do vetor
	pixel=ordena(pixel)
	resultado=pixel[1]
	return resultado
		
def media(pixel): # calcula a media do vetor pixel
	r=int(pixel[0])
	g=int(pixel[1])
	b=int(pixel[2])		
	resultado=(r+g+b)/3
	return resultado	

def moda(pixel): #calculo da moda do pixel. moda=3*mediana - 2*media
	resMedia=media(pixel) # resultado da funcao media
	resMediana=mediana(pixel) # resultado da funcao mediana
	moda=3*resMediana-2*resMedia
	return moda

def calculoTecnica(pixel,tecnica): # funcao que direciona qual tecnica de quantizacao sera usada
	if(tecnica=='media'):
		resultadoMedia=media(pixel)
		return resultadoMedia
	if(tecnica=='mediana'):
		resultadoMediana=mediana(pixel)
		return resultadoMediana
	if(tecnica=='moda'):
		resultadoModa=moda(pixel)
		return resultadoModa


