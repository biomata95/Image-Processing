#!/usr/bin/python
import sys
import numpy as np
import cv2
import math
import colorsys
import leituraVisualiza
import amostragem
import tecnicas
import quantizacao

 # Conversao de imagem para cinza. Primeiro para 256 tons de cinza.

def conversaoCinza(img,linhas,colunas,tecnica):
	for i in range(0,linhas):	
		for j in range(0,colunas):
			pixel=img[i,j]
			pixel=tecnicas.calculoTecnica(pixel,tecnica) # calcula a tecnica de quantizacao
			pixel2=int(pixel)
			img[i,j]=pixel2
	return img

